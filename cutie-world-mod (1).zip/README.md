# Cutie World (Forge 1.20.1)

Mod para Minecraft Forge 1.20.1 (Forge 47.2.0, Java 17). Cuatro estructuras que aparecen por el mundo, **cada una con una función real** y su propio mob muy cute.

## Las estructuras

| Estructura | Dónde aparece | Mob | Qué hace |
|---|---|---|---|
| **Café Mochi** | llanuras, praderas, bosques, bosque de flores, abedules, cerezos | **Mochi** (bolita dulce con brote en la cabeza, 3 colores) | Cafetería con cocina, mostrador, mesas y terraza. Los mochis son **comerciantes**: venden mochis con efectos, galletas y tarta, y compran bayas, azúcar y trigo. |
| **Fuente de las Hadas** | bosque de flores, praderas, cerezos, bosques | **Hadita** (vuela, 3 colores) | Plaza circular con la **Fuente de Hadas**: clic derecho = cura toda la vida, limpia efectos malos y da regeneración y absorción. Luego se duerme 5 min o se recarga al instante con **polvo de hada**. Las haditas se acercan a ti, **curan con regeneración a quien esté herido** y sueltan polvo de hada. Hay casitas-seta y arcos de flores. |
| **Huerto de los Conejitos** | llanuras, sabana, praderas, bosques | **Conejito Jardinero** (con sombrero de paja, 4 colores) | Huerto vallado con trigo, zanahorias, patatas y remolachas ya a medio crecer. Los conejitos **cosechan solos los cultivos maduros, los replantan y guardan la cosecha en la cesta (barril/cofre) más cercana**: una granja automática. Una zanahoria los pone contentos. |
| **Torre de los Buhitos** | bosques, taiga, bosque oscuro, abedules | **Buhito** (3 colores) | Torre de 3 plantas: biblioteca con **mesa de encantamiento rodeada de estanterías**, taller (cartografía, herrería, piedra de afilar, yunque, telar) con un **atril con la Guía del Mundo Cute** y observatorio con nidos. Los buhitos son **comerciantes**: venden **mapas que señalan el Café, la Fuente y el Huerto más cercanos**, libros encantados y estanterías. |

## Items
- **Mochi de fresa** (velocidad), **Mochi de matcha** (absorción + prisa), **Mochi de sakura** (salto + caída lenta). Se fabrican con bayas / alga seca / pétalos rosas + azúcar + trigo (da 2).
- **Polvo de hada**: recarga una fuente al instante.
- **Fuente de Hadas** (bloque): se puede fabricar `_D_ / AQA / QQQ` (D = polvo de hada, A = amatista, Q = bloque de cuarzo).
- Huevos generadores de los 4 mobs en la pestaña creativa "Cutie World".

## Encontrar las estructuras
`/locate structure cutieworld:cafe_mochi`, `cutieworld:fuente_hadas`, `cutieworld:huerto_conejitos`, `cutieworld:torre_buhitos`.
Frecuencia: `src/main/resources/data/cutieworld/worldgen/structure_set/*.json` (`spacing` = distancia media entre intentos en chunks).

## Compilar con GitHub (sin instalar nada)
1. Sube a un repositorio **este .zip tal cual** (sin descomprimir) y el archivo `.github/workflows/build.yml`
   (créalo con *Add file → Create new file* escribiendo la ruta `.github/workflows/build.yml`).
2. GitHub descomprime el zip, compila y deja el `.jar` en **Actions → último run → Artifacts → mod-jar**.
3. Copia el `.jar` a la carpeta `mods` de Forge 1.20.1.

Compilar en local: `gradle build` (Gradle 8.1.1, JDK 17). El jar queda en `build/libs/`.

## Notas de diseño
- Las estructuras son plantillas `.nbt` colocadas con el sistema *jigsaw* de Minecraft (sin generación por código), así que se pueden abrir y editar con bloques de estructura en el juego.
- Los mobs ya vienen dentro de las plantillas (con `PersistenceRequired`) y viven cerca de su estructura.
