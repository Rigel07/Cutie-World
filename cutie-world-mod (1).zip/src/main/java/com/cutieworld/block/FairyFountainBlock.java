package com.cutieworld.block;

import com.cutieworld.registry.ModItems;
import java.util.ArrayList;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Fuente de hadas. Clic derecho: cura toda la vida, quita los efectos malos y da regeneracion y absorcion.
 * Despues se queda sin magia durante 5 minutos, o se recarga al instante con polvo de hada.
 */
public class FairyFountainBlock extends Block {
    public static final BooleanProperty CHARGED = BooleanProperty.create("charged");
    public static final int RECHARGE_TICKS = 6000;

    private static final VoxelShape SHAPE = Shapes.or(
            Block.box(1.0D, 0.0D, 1.0D, 15.0D, 5.0D, 15.0D),
            Block.box(5.0D, 5.0D, 5.0D, 11.0D, 12.0D, 11.0D),
            Block.box(3.0D, 12.0D, 3.0D, 13.0D, 16.0D, 13.0D));

    public FairyFountainBlock(Properties properties) {
        super(properties);
        this.registerDefaultState(this.stateDefinition.any().setValue(CHARGED, true));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(CHARGED);
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return SHAPE;
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player,
                                 InteractionHand hand, BlockHitResult hit) {
        if (level.isClientSide) {
            return InteractionResult.SUCCESS;
        }
        ItemStack held = player.getItemInHand(hand);

        if (!state.getValue(CHARGED)) {
            if (held.is(ModItems.FAIRY_DUST.get())) {
                if (!player.getAbilities().instabuild) {
                    held.shrink(1);
                }
                recharge(level, pos, state);
            } else {
                player.displayClientMessage(Component.translatable("message.cutieworld.fountain_empty"), true);
            }
            return InteractionResult.CONSUME;
        }

        player.heal(player.getMaxHealth());
        player.getFoodData().eat(6, 0.6F);
        for (MobEffectInstance effect : new ArrayList<>(player.getActiveEffects())) {
            if (effect.getEffect().getCategory() == MobEffectCategory.HARMFUL) {
                player.removeEffect(effect.getEffect());
            }
        }
        player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 200, 1));
        player.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 1200, 1));

        level.setBlock(pos, state.setValue(CHARGED, false), 3);
        level.scheduleTick(pos, this, RECHARGE_TICKS);
        level.playSound(null, pos, SoundEvents.AMETHYST_BLOCK_RESONATE, SoundSource.BLOCKS, 1.2F, 1.2F);
        if (level instanceof ServerLevel serverLevel) {
            serverLevel.sendParticles(ParticleTypes.HEART, player.getX(), player.getY() + 1.2D, player.getZ(),
                    8, 0.4D, 0.4D, 0.4D, 0.0D);
            serverLevel.sendParticles(ParticleTypes.END_ROD, pos.getX() + 0.5D, pos.getY() + 1.1D, pos.getZ() + 0.5D,
                    16, 0.3D, 0.3D, 0.3D, 0.04D);
        }
        return InteractionResult.CONSUME;
    }

    private void recharge(Level level, BlockPos pos, BlockState state) {
        level.setBlock(pos, state.setValue(CHARGED, true), 3);
        level.playSound(null, pos, SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.BLOCKS, 1.0F, 1.4F);
        if (level instanceof ServerLevel serverLevel) {
            serverLevel.sendParticles(ParticleTypes.END_ROD, pos.getX() + 0.5D, pos.getY() + 1.0D, pos.getZ() + 0.5D,
                    12, 0.3D, 0.3D, 0.3D, 0.03D);
        }
    }

    @Override
    public void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        if (!state.getValue(CHARGED)) {
            recharge(level, pos, state);
        }
    }

    @Override
    public void animateTick(BlockState state, Level level, BlockPos pos, RandomSource random) {
        if (state.getValue(CHARGED) && random.nextInt(6) == 0) {
            level.addParticle(random.nextBoolean() ? ParticleTypes.END_ROD : ParticleTypes.HAPPY_VILLAGER,
                    pos.getX() + 0.2D + random.nextDouble() * 0.6D,
                    pos.getY() + 1.0D + random.nextDouble() * 0.4D,
                    pos.getZ() + 0.2D + random.nextDouble() * 0.6D,
                    0.0D, 0.02D, 0.0D);
        }
    }
}
