package com.cutieworld;

import com.cutieworld.registry.ModBlocks;
import com.cutieworld.registry.ModCreativeTabs;
import com.cutieworld.registry.ModEntities;
import com.cutieworld.registry.ModItems;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(CutieWorldMod.MODID)
public class CutieWorldMod {
    public static final String MODID = "cutieworld";

    public CutieWorldMod() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        ModBlocks.BLOCKS.register(modBus);
        ModItems.ITEMS.register(modBus);
        ModEntities.ENTITY_TYPES.register(modBus);
        ModCreativeTabs.TABS.register(modBus);
    }
}
