package com.cutieworld.entity;

import com.cutieworld.registry.ModItems;
import java.util.Comparator;
import java.util.EnumSet;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.control.FlyingMoveControl;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.PanicGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomFlyingGoal;
import net.minecraft.world.entity.ai.navigation.FlyingPathNavigation;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;

/**
 * Hadita: guardiana de la fuente. Revolotea cerca de los visitantes y cura (regeneracion)
 * a quien este herido. De vez en cuando suelta polvo de hada.
 */
public class FairyEntity extends PathfinderMob {
    public static final int VARIANTS = 3;
    private static final int HOME_RADIUS = 14;

    private static final EntityDataAccessor<Integer> DATA_VARIANT =
            SynchedEntityData.defineId(FairyEntity.class, EntityDataSerializers.INT);

    @Nullable
    private BlockPos home;
    private int dustTimer;
    private int healCooldown;

    public FairyEntity(EntityType<? extends FairyEntity> type, Level level) {
        super(type, level);
        this.moveControl = new FlyingMoveControl(this, 20, true);
        this.setNoGravity(true);
        this.dustTimer = nextDustDelay(this.random);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 8.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.2D)
                .add(Attributes.FLYING_SPEED, 0.45D);
    }

    private static int nextDustDelay(RandomSource random) {
        return 3600 + random.nextInt(2400);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(1, new PanicGoal(this, 1.4D));
        this.goalSelector.addGoal(2, new ApproachPlayerGoal(this));
        this.goalSelector.addGoal(3, new WaterAvoidingRandomFlyingGoal(this, 0.7D));
        this.goalSelector.addGoal(4, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(5, new RandomLookAroundGoal(this));
    }

    @Override
    protected PathNavigation createNavigation(Level level) {
        FlyingPathNavigation navigation = new FlyingPathNavigation(this, level);
        navigation.setCanOpenDoors(false);
        navigation.setCanFloat(true);
        navigation.setCanPassDoors(true);
        return navigation;
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_VARIANT, 0);
    }

    public int getVariant() {
        return Math.floorMod(this.entityData.get(DATA_VARIANT), VARIANTS);
    }

    public void setVariant(int variant) {
        this.entityData.set(DATA_VARIANT, variant);
    }

    @Override
    @Nullable
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty,
                                        MobSpawnType reason, @Nullable SpawnGroupData data,
                                        @Nullable CompoundTag tag) {
        this.setVariant(this.random.nextInt(VARIANTS));
        return super.finalizeSpawn(level, difficulty, reason, data, tag);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Variant", this.entityData.get(DATA_VARIANT));
        tag.putInt("DustTimer", this.dustTimer);
        if (this.home != null) {
            tag.putIntArray("Home", new int[]{this.home.getX(), this.home.getY(), this.home.getZ()});
        }
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.setVariant(tag.getInt("Variant"));
        if (tag.contains("DustTimer")) {
            this.dustTimer = tag.getInt("DustTimer");
        }
        if (tag.contains("Home", Tag.TAG_INT_ARRAY)) {
            int[] h = tag.getIntArray("Home");
            if (h.length == 3) {
                this.home = new BlockPos(h[0], h[1], h[2]);
                this.restrictTo(this.home, HOME_RADIUS);
            }
        }
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (this.level().isClientSide) {
            if (this.random.nextInt(4) == 0) {
                this.level().addParticle(ParticleTypes.END_ROD,
                        this.getX() + (this.random.nextDouble() - 0.5D) * 0.5D,
                        this.getY() + 0.3D,
                        this.getZ() + (this.random.nextDouble() - 0.5D) * 0.5D,
                        0.0D, -0.01D, 0.0D);
            }
            return;
        }
        if (this.home == null) {
            this.home = this.blockPosition();
            this.restrictTo(this.home, HOME_RADIUS);
        }

        // cura a quien este herido cerca
        if (this.healCooldown > 0) {
            this.healCooldown--;
        } else if (this.tickCount % 20 == 0) {
            AABB area = this.getBoundingBox().inflate(7.0D);
            List<Player> hurt = this.level().getEntitiesOfClass(Player.class, area,
                    p -> p.isAlive() && !p.isSpectator() && p.getHealth() < p.getMaxHealth());
            if (!hurt.isEmpty()) {
                for (Player player : hurt) {
                    player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 120, 0));
                    if (this.level() instanceof ServerLevel serverLevel) {
                        serverLevel.sendParticles(ParticleTypes.HEART, player.getX(), player.getY() + 1.4D, player.getZ(),
                                3, 0.3D, 0.2D, 0.3D, 0.0D);
                    }
                }
                this.level().playSound(null, this.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME,
                        SoundSource.NEUTRAL, 0.8F, 1.6F);
                this.healCooldown = 160;
            }
        }

        // polvo de hada
        if (--this.dustTimer <= 0) {
            this.dustTimer = nextDustDelay(this.random);
            this.spawnAtLocation(new ItemStack(ModItems.FAIRY_DUST.get()));
            if (this.level() instanceof ServerLevel serverLevel) {
                serverLevel.sendParticles(ParticleTypes.END_ROD, this.getX(), this.getY() + 0.3D, this.getZ(),
                        10, 0.25D, 0.25D, 0.25D, 0.02D);
            }
        }
    }

    @Override
    public boolean causeFallDamage(float distance, float multiplier, DamageSource source) {
        return false;
    }

    @Override
    protected void checkFallDamage(double y, boolean onGround, BlockState state, BlockPos pos) {
    }

    @Override
    public boolean isPushedByFluid() {
        return false;
    }

    @Override
    public int getAmbientSoundInterval() {
        return 220;
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.AMETHYST_BLOCK_CHIME;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.AMETHYST_BLOCK_HIT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.AMETHYST_CLUSTER_BREAK;
    }

    @Override
    public float getVoicePitch() {
        return 1.3F + (this.random.nextFloat() - this.random.nextFloat()) * 0.3F;
    }

    /** Se acerca con carino al jugador mas cercano y revolotea a su alrededor. */
    private static class ApproachPlayerGoal extends Goal {
        private final FairyEntity fairy;
        private Player target;
        private int recalc;
        private int patience;

        ApproachPlayerGoal(FairyEntity fairy) {
            this.fairy = fairy;
            this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            if (this.fairy.getRandom().nextInt(15) != 0) {
                return false;
            }
            AABB area = this.fairy.getBoundingBox().inflate(12.0D);
            List<Player> players = this.fairy.level().getEntitiesOfClass(Player.class, area,
                    p -> p.isAlive() && !p.isSpectator() && this.fairy.hasLineOfSight(p));
            this.target = players.stream()
                    .min(Comparator.comparingDouble(p -> p.distanceToSqr(this.fairy)))
                    .orElse(null);
            return this.target != null;
        }

        @Override
        public boolean canContinueToUse() {
            return this.target != null && this.target.isAlive() && this.patience > 0
                    && this.fairy.distanceToSqr(this.target) < 20.0D * 20.0D;
        }

        @Override
        public void start() {
            this.patience = 160 + this.fairy.getRandom().nextInt(160);
            this.recalc = 0;
        }

        @Override
        public void tick() {
            this.patience--;
            this.fairy.getLookControl().setLookAt(this.target, 30.0F, 30.0F);
            if (this.fairy.distanceTo(this.target) > 2.5D) {
                if (--this.recalc <= 0) {
                    this.recalc = 8;
                    this.fairy.getNavigation().moveTo(this.target.getX(),
                            this.target.getY() + this.target.getBbHeight() + 0.2D,
                            this.target.getZ(), 1.0D);
                }
            } else {
                this.fairy.getNavigation().stop();
            }
        }

        @Override
        public void stop() {
            this.target = null;
            this.fairy.getNavigation().stop();
        }
    }
}
