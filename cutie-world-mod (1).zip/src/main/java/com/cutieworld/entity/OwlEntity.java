package com.cutieworld.entity;

import com.cutieworld.entity.trade.EnchantedBookListing;
import com.cutieworld.entity.trade.MapListing;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.npc.VillagerTrades;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.trading.MerchantOffer;
import net.minecraft.world.item.trading.MerchantOffers;
import net.minecraft.world.level.Level;

/** Buhito: bibliotecario y cartografo. Vende mapas a las demas estructuras cute y libros encantados. */
public class OwlEntity extends CuteMerchantEntity {
    public OwlEntity(EntityType<? extends OwlEntity> type, Level level) {
        super(type, level);
    }

    @Override
    protected int variantCount() {
        return 3;
    }

    @Override
    protected void updateTrades() {
        MerchantOffers offers = this.getOffers();
        VillagerTrades.ItemListing[] listings = {
                new MapListing(6, ModStructureTags.CAFE, "filled_map.cutieworld.cafe", 8, 8),
                new MapListing(7, ModStructureTags.FOUNTAIN, "filled_map.cutieworld.fountain", 8, 8),
                new MapListing(8, ModStructureTags.GARDEN, "filled_map.cutieworld.garden", 8, 8),
                new EnchantedBookListing(8),
                new EnchantedBookListing(8)
        };
        for (VillagerTrades.ItemListing listing : listings) {
            MerchantOffer offer = listing.getOffer(this, this.random);
            if (offer != null) {
                offers.add(offer);
            }
        }
        offers.add(new MerchantOffer(new ItemStack(Items.PAPER, 24), new ItemStack(Items.EMERALD, 1), 16, 2, 0.05F));
        offers.add(new MerchantOffer(new ItemStack(Items.LAPIS_LAZULI, 5), new ItemStack(Items.EMERALD, 1), 16, 3, 0.05F));
        offers.add(new MerchantOffer(new ItemStack(Items.EMERALD, 2), new ItemStack(Items.BOOK, 3), 12, 2, 0.05F));
        offers.add(new MerchantOffer(new ItemStack(Items.EMERALD, 3), new ItemStack(Items.BOOKSHELF, 2), 12, 3, 0.05F));
        offers.add(new MerchantOffer(new ItemStack(Items.EMERALD, 6), new ItemStack(Items.SPYGLASS, 1), 4, 5, 0.05F));
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.PARROT_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.PARROT_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.PARROT_DEATH;
    }

    @Override
    public float getVoicePitch() {
        return 0.7F + (this.random.nextFloat() - this.random.nextFloat()) * 0.1F;
    }
}
