package com.cutieworld.entity;

import com.cutieworld.CutieWorldMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.level.levelgen.structure.Structure;

/** Etiquetas de estructura usadas por los mapas del buhito. */
public final class ModStructureTags {
    public static final TagKey<Structure> CAFE = tag("cafe_mochi");
    public static final TagKey<Structure> FOUNTAIN = tag("fuente_hadas");
    public static final TagKey<Structure> GARDEN = tag("huerto_conejitos");

    private ModStructureTags() {}

    private static TagKey<Structure> tag(String name) {
        return TagKey.create(Registries.STRUCTURE, new ResourceLocation(CutieWorldMod.MODID, name));
    }
}
