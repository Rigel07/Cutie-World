package com.cutieworld.entity;

import com.cutieworld.CutieWorldMod;
import com.cutieworld.registry.ModEntities;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = CutieWorldMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class ModEntityEvents {
    private ModEntityEvents() {}

    @SubscribeEvent
    public static void onAttributes(EntityAttributeCreationEvent event) {
        event.put(ModEntities.MOCHI.get(), CuteMerchantEntity.createAttributes().build());
        event.put(ModEntities.OWL.get(), CuteMerchantEntity.createAttributes().build());
        event.put(ModEntities.FAIRY.get(), FairyEntity.createAttributes().build());
        event.put(ModEntities.GARDEN_BUNNY.get(), GardenBunnyEntity.createAttributes().build());
    }
}
