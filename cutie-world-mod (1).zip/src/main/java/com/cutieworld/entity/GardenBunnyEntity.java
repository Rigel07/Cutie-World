package com.cutieworld.entity;

import java.util.EnumSet;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.PanicGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.TemptGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.CropBlock;
import net.minecraft.world.level.block.entity.BarrelBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.entity.HopperBlockEntity;
import net.minecraft.world.Container;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Conejito jardinero: cosecha los cultivos maduros de su huerto, los vuelve a plantar
 * y guarda la cosecha en la cesta (barril o cofre) mas cercana.
 */
public class GardenBunnyEntity extends PathfinderMob {
    public static final int VARIANTS = 4;
    private static final int HOME_RADIUS = 16;

    private static final EntityDataAccessor<Integer> DATA_VARIANT =
            SynchedEntityData.defineId(GardenBunnyEntity.class, EntityDataSerializers.INT);

    @Nullable
    private BlockPos home;

    public GardenBunnyEntity(EntityType<? extends GardenBunnyEntity> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 8.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.3D);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new PanicGoal(this, 1.6D));
        this.goalSelector.addGoal(2, new TendGardenGoal(this));
        this.goalSelector.addGoal(3, new TemptGoal(this, 1.0D,
                Ingredient.of(Items.CARROT, Items.GOLDEN_CARROT, Items.DANDELION), false));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 6.0F));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_VARIANT, 0);
    }

    public int getVariant() {
        return Math.floorMod(this.entityData.get(DATA_VARIANT), VARIANTS);
    }

    public void setVariant(int variant) {
        this.entityData.set(DATA_VARIANT, variant);
    }

    @Override
    @Nullable
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty,
                                        MobSpawnType reason, @Nullable SpawnGroupData data,
                                        @Nullable CompoundTag tag) {
        this.setVariant(this.random.nextInt(VARIANTS));
        return super.finalizeSpawn(level, difficulty, reason, data, tag);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Variant", this.entityData.get(DATA_VARIANT));
        if (this.home != null) {
            tag.putIntArray("Home", new int[]{this.home.getX(), this.home.getY(), this.home.getZ()});
        }
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.setVariant(tag.getInt("Variant"));
        if (tag.contains("Home", Tag.TAG_INT_ARRAY)) {
            int[] h = tag.getIntArray("Home");
            if (h.length == 3) {
                this.home = new BlockPos(h[0], h[1], h[2]);
                this.restrictTo(this.home, HOME_RADIUS);
            }
        }
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (!this.level().isClientSide && this.home == null) {
            this.home = this.blockPosition();
            this.restrictTo(this.home, HOME_RADIUS);
        }
    }

    /** Una zanahoria (o una flor) y se pone contento. */
    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (stack.is(Items.CARROT) || stack.is(Items.GOLDEN_CARROT) || stack.is(Items.DANDELION)) {
            if (!this.level().isClientSide && this.level() instanceof ServerLevel serverLevel) {
                if (!player.getAbilities().instabuild) {
                    stack.shrink(1);
                }
                this.heal(2.0F);
                serverLevel.sendParticles(ParticleTypes.HEART, this.getX(), this.getY() + 0.8D, this.getZ(),
                        5, 0.3D, 0.3D, 0.3D, 0.0D);
                this.playSound(SoundEvents.RABBIT_AMBIENT, 1.0F, 1.3F);
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide);
        }
        return super.mobInteract(player, hand);
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.RABBIT_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.RABBIT_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.RABBIT_DEATH;
    }

    @Override
    protected void playStepSound(BlockPos pos, BlockState state) {
        this.playSound(SoundEvents.RABBIT_JUMP, 0.12F, 1.4F);
    }

    // ---------------------------------------------------------------- jardineria

    /** Guarda lo cosechado en la cesta cercana; lo que no cabe cae al suelo. */
    private void storeHarvest(ServerLevel level, BlockPos cropPos, List<ItemStack> drops) {
        Container basket = findBasket(level);
        for (ItemStack drop : drops) {
            ItemStack rest = drop.copy();
            if (basket != null) {
                rest = HopperBlockEntity.addItem(null, basket, rest, null);
            }
            if (!rest.isEmpty()) {
                Block.popResource(level, cropPos, rest);
            }
        }
    }

    @Nullable
    private Container findBasket(ServerLevel level) {
        BlockPos center = this.blockPosition();
        Container best = null;
        double bestDistance = Double.MAX_VALUE;
        for (BlockPos pos : BlockPos.betweenClosed(center.offset(-10, -3, -10), center.offset(10, 3, 10))) {
            BlockEntity blockEntity = level.getBlockEntity(pos);
            if (blockEntity instanceof BarrelBlockEntity || blockEntity instanceof ChestBlockEntity) {
                double distance = pos.distSqr(center);
                if (distance < bestDistance) {
                    bestDistance = distance;
                    best = (Container) blockEntity;
                }
            }
        }
        return best;
    }

    private static class TendGardenGoal extends Goal {
        private final GardenBunnyEntity bunny;
        private BlockPos target;
        private int scanDelay;
        private int timeout;

        TendGardenGoal(GardenBunnyEntity bunny) {
            this.bunny = bunny;
            this.setFlags(EnumSet.of(Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            if (this.bunny.level().isClientSide) {
                return false;
            }
            if (--this.scanDelay > 0) {
                return false;
            }
            this.scanDelay = 30 + this.bunny.getRandom().nextInt(30);
            this.target = findMatureCrop();
            return this.target != null;
        }

        @Nullable
        private BlockPos findMatureCrop() {
            Level level = this.bunny.level();
            BlockPos center = this.bunny.blockPosition();
            BlockPos best = null;
            double bestDistance = Double.MAX_VALUE;
            for (BlockPos pos : BlockPos.betweenClosed(center.offset(-8, -1, -8), center.offset(8, 1, 8))) {
                BlockState state = level.getBlockState(pos);
                if (state.getBlock() instanceof CropBlock crop && crop.isMaxAge(state)) {
                    double distance = pos.distSqr(center);
                    if (distance < bestDistance) {
                        bestDistance = distance;
                        best = pos.immutable();
                    }
                }
            }
            return best;
        }

        @Override
        public boolean canContinueToUse() {
            if (this.target == null || this.timeout <= 0) {
                return false;
            }
            BlockState state = this.bunny.level().getBlockState(this.target);
            return state.getBlock() instanceof CropBlock crop && crop.isMaxAge(state);
        }

        @Override
        public void start() {
            this.timeout = 200;
            this.bunny.getNavigation().moveTo(this.target.getX() + 0.5D, this.target.getY(),
                    this.target.getZ() + 0.5D, 1.1D);
        }

        @Override
        public void tick() {
            this.timeout--;
            double dx = this.bunny.getX() - (this.target.getX() + 0.5D);
            double dz = this.bunny.getZ() - (this.target.getZ() + 0.5D);
            double dy = this.bunny.getY() - this.target.getY();
            if (dx * dx + dz * dz < 1.8D * 1.8D && Math.abs(dy) < 2.0D) {
                harvest();
                this.target = null;
            } else if (this.bunny.getNavigation().isDone()) {
                this.bunny.getNavigation().moveTo(this.target.getX() + 0.5D, this.target.getY(),
                        this.target.getZ() + 0.5D, 1.1D);
            }
        }

        private void harvest() {
            if (!(this.bunny.level() instanceof ServerLevel level)) {
                return;
            }
            BlockState state = level.getBlockState(this.target);
            if (state.getBlock() instanceof CropBlock crop && crop.isMaxAge(state)) {
                List<ItemStack> drops = Block.getDrops(state, level, this.target, null);
                level.setBlock(this.target, crop.getStateForAge(0), 3);
                level.playSound(null, this.target, SoundEvents.CROP_BREAK, SoundSource.BLOCKS, 1.0F, 1.2F);
                level.sendParticles(ParticleTypes.HAPPY_VILLAGER, this.target.getX() + 0.5D, this.target.getY() + 0.4D,
                        this.target.getZ() + 0.5D, 6, 0.3D, 0.2D, 0.3D, 0.0D);
                this.bunny.storeHarvest(level, this.target, drops);
            }
        }

        @Override
        public void stop() {
            this.target = null;
            this.bunny.getNavigation().stop();
            this.scanDelay = 10;
        }
    }
}
