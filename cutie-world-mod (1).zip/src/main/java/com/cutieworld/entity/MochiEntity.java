package com.cutieworld.entity;

import com.cutieworld.registry.ModItems;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.trading.MerchantOffer;
import net.minecraft.world.item.trading.MerchantOffers;
import net.minecraft.world.level.Level;

/** Mochi: bolita dulce que atiende el cafe. Vende dulces con efectos y compra ingredientes. */
public class MochiEntity extends CuteMerchantEntity {
    public MochiEntity(EntityType<? extends MochiEntity> type, Level level) {
        super(type, level);
    }

    @Override
    protected int variantCount() {
        return 3;
    }

    @Override
    protected void updateTrades() {
        MerchantOffers offers = this.getOffers();
        offers.add(new MerchantOffer(new ItemStack(Items.EMERALD, 1), new ItemStack(ModItems.STRAWBERRY_MOCHI.get(), 3), 16, 2, 0.05F));
        offers.add(new MerchantOffer(new ItemStack(Items.EMERALD, 1), new ItemStack(ModItems.MATCHA_MOCHI.get(), 3), 16, 2, 0.05F));
        offers.add(new MerchantOffer(new ItemStack(Items.EMERALD, 2), new ItemStack(ModItems.SAKURA_MOCHI.get(), 2), 12, 3, 0.05F));
        offers.add(new MerchantOffer(new ItemStack(Items.EMERALD, 1), new ItemStack(Items.COOKIE, 8), 16, 1, 0.05F));
        offers.add(new MerchantOffer(new ItemStack(Items.EMERALD, 2), new ItemStack(Items.CAKE, 1), 8, 3, 0.05F));
        offers.add(new MerchantOffer(new ItemStack(Items.SWEET_BERRIES, 10), new ItemStack(Items.EMERALD, 1), 16, 3, 0.05F));
        offers.add(new MerchantOffer(new ItemStack(Items.SUGAR, 12), new ItemStack(Items.EMERALD, 1), 16, 3, 0.05F));
        offers.add(new MerchantOffer(new ItemStack(Items.WHEAT, 16), new ItemStack(Items.EMERALD, 1), 16, 3, 0.05F));
        offers.add(new MerchantOffer(new ItemStack(Items.EMERALD, 5), new ItemStack(Items.GOLDEN_CARROT, 3), 8, 5, 0.05F));
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.SLIME_SQUISH_SMALL;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.SLIME_HURT_SMALL;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.SLIME_DEATH_SMALL;
    }

    @Override
    public float getVoicePitch() {
        return 1.5F + (this.random.nextFloat() - this.random.nextFloat()) * 0.2F;
    }
}
