package com.cutieworld.entity.trade;

import javax.annotation.Nullable;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.TagKey;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.npc.VillagerTrades;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.MapItem;
import net.minecraft.world.item.trading.MerchantOffer;
import net.minecraft.world.level.levelgen.structure.Structure;
import net.minecraft.world.level.saveddata.maps.MapDecoration;
import net.minecraft.world.level.saveddata.maps.MapItemSavedData;

/** Vende un mapa que senala la estructura mas cercana de un tipo (como los cartografos). */
public class MapListing implements VillagerTrades.ItemListing {
    private final int emeraldCost;
    private final TagKey<Structure> destination;
    private final String nameKey;
    private final int maxUses;
    private final int xp;

    public MapListing(int emeraldCost, TagKey<Structure> destination, String nameKey, int maxUses, int xp) {
        this.emeraldCost = emeraldCost;
        this.destination = destination;
        this.nameKey = nameKey;
        this.maxUses = maxUses;
        this.xp = xp;
    }

    @Nullable
    @Override
    public MerchantOffer getOffer(Entity trader, RandomSource random) {
        if (!(trader.level() instanceof ServerLevel level)) {
            return null;
        }
        BlockPos pos = level.findNearestMapStructure(this.destination, trader.blockPosition(), 100, true);
        if (pos == null) {
            return null;
        }
        ItemStack map = MapItem.create(level, pos.getX(), pos.getZ(), (byte) 2, true, true);
        MapItem.renderBiomePreviewMap(level, map);
        MapItemSavedData.addTargetDecoration(map, pos, "+", MapDecoration.Type.RED_X);
        map.setHoverName(Component.translatable(this.nameKey));
        return new MerchantOffer(new ItemStack(Items.EMERALD, this.emeraldCost), new ItemStack(Items.COMPASS),
                map, this.maxUses, this.xp, 0.2F);
    }
}
