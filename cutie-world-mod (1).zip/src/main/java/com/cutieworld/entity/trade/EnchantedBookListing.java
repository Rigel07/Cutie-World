package com.cutieworld.entity.trade;

import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.npc.VillagerTrades;
import net.minecraft.world.item.EnchantedBookItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.EnchantmentInstance;
import net.minecraft.world.item.trading.MerchantOffer;

/** Libro encantado al azar a cambio de esmeraldas y un libro. */
public class EnchantedBookListing implements VillagerTrades.ItemListing {
    private final int xp;

    public EnchantedBookListing(int xp) {
        this.xp = xp;
    }

    @Nullable
    @Override
    public MerchantOffer getOffer(Entity trader, RandomSource random) {
        List<Enchantment> candidates = BuiltInRegistries.ENCHANTMENT.stream().filter(Enchantment::isTradeable).toList();
        if (candidates.isEmpty()) {
            return null;
        }
        Enchantment enchantment = candidates.get(random.nextInt(candidates.size()));
        int level = Mth.nextInt(random, enchantment.getMinLevel(), enchantment.getMaxLevel());
        ItemStack book = EnchantedBookItem.createForEnchantment(new EnchantmentInstance(enchantment, level));
        int cost = 2 + random.nextInt(5 + level * 10) + 3 * level;
        if (enchantment.isTreasureOnly()) {
            cost *= 2;
        }
        cost = Math.min(cost, 64);
        return new MerchantOffer(new ItemStack(Items.EMERALD, cost), new ItemStack(Items.BOOK), book, 12, this.xp, 0.2F);
    }
}
