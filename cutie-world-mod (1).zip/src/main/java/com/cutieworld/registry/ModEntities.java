package com.cutieworld.registry;

import com.cutieworld.CutieWorldMod;
import com.cutieworld.entity.FairyEntity;
import com.cutieworld.entity.GardenBunnyEntity;
import com.cutieworld.entity.MochiEntity;
import com.cutieworld.entity.OwlEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, CutieWorldMod.MODID);

    public static final RegistryObject<EntityType<MochiEntity>> MOCHI = ENTITY_TYPES.register("mochi",
            () -> EntityType.Builder.<MochiEntity>of(MochiEntity::new, MobCategory.CREATURE)
                    .sized(0.7F, 0.8F).clientTrackingRange(10)
                    .build(CutieWorldMod.MODID + ":mochi"));

    public static final RegistryObject<EntityType<FairyEntity>> FAIRY = ENTITY_TYPES.register("fairy",
            () -> EntityType.Builder.<FairyEntity>of(FairyEntity::new, MobCategory.CREATURE)
                    .sized(0.45F, 0.75F).clientTrackingRange(10)
                    .build(CutieWorldMod.MODID + ":fairy"));

    public static final RegistryObject<EntityType<GardenBunnyEntity>> GARDEN_BUNNY = ENTITY_TYPES.register("garden_bunny",
            () -> EntityType.Builder.<GardenBunnyEntity>of(GardenBunnyEntity::new, MobCategory.CREATURE)
                    .sized(0.5F, 0.8F).clientTrackingRange(10)
                    .build(CutieWorldMod.MODID + ":garden_bunny"));

    public static final RegistryObject<EntityType<OwlEntity>> OWL = ENTITY_TYPES.register("owl",
            () -> EntityType.Builder.<OwlEntity>of(OwlEntity::new, MobCategory.CREATURE)
                    .sized(0.6F, 1.05F).clientTrackingRange(10)
                    .build(CutieWorldMod.MODID + ":owl"));

    private ModEntities() {}
}
