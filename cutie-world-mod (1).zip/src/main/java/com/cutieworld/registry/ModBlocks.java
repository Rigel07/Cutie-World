package com.cutieworld.registry;

import com.cutieworld.CutieWorldMod;
import com.cutieworld.block.FairyFountainBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, CutieWorldMod.MODID);

    /** Fuente de hadas: cura por completo y se recarga con el tiempo o con polvo de hada. */
    public static final RegistryObject<Block> FAIRY_FOUNTAIN = BLOCKS.register("fairy_fountain",
            () -> new FairyFountainBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.COLOR_PINK)
                    .strength(3.0F, 6.0F)
                    .sound(SoundType.AMETHYST)
                    .lightLevel(state -> state.getValue(FairyFountainBlock.CHARGED) ? 12 : 0)
                    .noOcclusion()));

    private ModBlocks() {}
}
