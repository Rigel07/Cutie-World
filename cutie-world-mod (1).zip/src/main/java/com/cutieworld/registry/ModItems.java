package com.cutieworld.registry;

import com.cutieworld.CutieWorldMod;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, CutieWorldMod.MODID);

    /** Mochi de fresa: rapido y energico. */
    public static final RegistryObject<Item> STRAWBERRY_MOCHI = ITEMS.register("strawberry_mochi",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder()
                    .nutrition(5).saturationMod(0.6F).fast()
                    .effect(() -> new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 600, 0), 1.0F)
                    .build())));

    /** Mochi de matcha: vitalidad y manos agiles. */
    public static final RegistryObject<Item> MATCHA_MOCHI = ITEMS.register("matcha_mochi",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder()
                    .nutrition(5).saturationMod(0.6F).fast()
                    .effect(() -> new MobEffectInstance(MobEffects.ABSORPTION, 1200, 0), 1.0F)
                    .effect(() -> new MobEffectInstance(MobEffects.DIG_SPEED, 600, 0), 1.0F)
                    .build())));

    /** Mochi de sakura: ligero como un petalo. */
    public static final RegistryObject<Item> SAKURA_MOCHI = ITEMS.register("sakura_mochi",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder()
                    .nutrition(6).saturationMod(0.8F).fast()
                    .effect(() -> new MobEffectInstance(MobEffects.JUMP, 900, 1), 1.0F)
                    .effect(() -> new MobEffectInstance(MobEffects.SLOW_FALLING, 900, 0), 1.0F)
                    .build())));

    /** Polvo de hada: recarga al instante una fuente de hadas. */
    public static final RegistryObject<Item> FAIRY_DUST = ITEMS.register("fairy_dust",
            () -> new Item(new Item.Properties().rarity(Rarity.UNCOMMON)));

    public static final RegistryObject<Item> FAIRY_FOUNTAIN = ITEMS.register("fairy_fountain",
            () -> new BlockItem(ModBlocks.FAIRY_FOUNTAIN.get(), new Item.Properties().rarity(Rarity.RARE)));

    public static final RegistryObject<Item> MOCHI_SPAWN_EGG = ITEMS.register("mochi_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.MOCHI, 0xFFF3F7, 0xFF9EC4, new Item.Properties()));
    public static final RegistryObject<Item> FAIRY_SPAWN_EGG = ITEMS.register("fairy_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.FAIRY, 0xFFB3D9, 0xA8E6FF, new Item.Properties()));
    public static final RegistryObject<Item> GARDEN_BUNNY_SPAWN_EGG = ITEMS.register("garden_bunny_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.GARDEN_BUNNY, 0xF2D9B8, 0xF5D36A, new Item.Properties()));
    public static final RegistryObject<Item> OWL_SPAWN_EGG = ITEMS.register("owl_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.OWL, 0xB98B62, 0xFFF1C9, new Item.Properties()));

    private ModItems() {}
}
