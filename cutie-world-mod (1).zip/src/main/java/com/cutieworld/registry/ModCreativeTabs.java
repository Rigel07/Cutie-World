package com.cutieworld.registry;

import com.cutieworld.CutieWorldMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public final class ModCreativeTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, CutieWorldMod.MODID);

    public static final RegistryObject<CreativeModeTab> MAIN = TABS.register("cutieworld",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.cutieworld"))
                    .icon(() -> new ItemStack(ModItems.STRAWBERRY_MOCHI.get()))
                    .displayItems((parameters, output) -> {
                        output.accept(ModItems.MOCHI_SPAWN_EGG.get());
                        output.accept(ModItems.FAIRY_SPAWN_EGG.get());
                        output.accept(ModItems.GARDEN_BUNNY_SPAWN_EGG.get());
                        output.accept(ModItems.OWL_SPAWN_EGG.get());
                        output.accept(ModItems.STRAWBERRY_MOCHI.get());
                        output.accept(ModItems.MATCHA_MOCHI.get());
                        output.accept(ModItems.SAKURA_MOCHI.get());
                        output.accept(ModItems.FAIRY_DUST.get());
                        output.accept(ModItems.FAIRY_FOUNTAIN.get());
                    })
                    .build());

    private ModCreativeTabs() {}
}
