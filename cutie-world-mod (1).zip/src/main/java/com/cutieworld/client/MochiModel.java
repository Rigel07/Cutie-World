package com.cutieworld.client;

import com.cutieworld.CutieWorldMod;
import com.cutieworld.entity.MochiEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/** Modelo generado a partir de la especificacion de partes (ver models.py). */
public class MochiModel extends EntityModel<MochiEntity> {
    public static final ModelLayerLocation LAYER_LOCATION =
            new ModelLayerLocation(new ResourceLocation(CutieWorldMod.MODID, "mochi"), "main");

    private final ModelPart root;
    private final ModelPart body;
    private final ModelPart sprout;
    private final ModelPart leaf;
    private final ModelPart armLeft;
    private final ModelPart armRight;
    private final ModelPart footLeft;
    private final ModelPart footRight;

    public MochiModel(ModelPart root) {
        this.root = root;
        this.body = root.getChild("body");
        this.sprout = this.body.getChild("sprout");
        this.leaf = this.body.getChild("leaf");
        this.armLeft = this.body.getChild("armLeft");
        this.armRight = this.body.getChild("armRight");
        this.footLeft = this.body.getChild("footLeft");
        this.footRight = this.body.getChild("footRight");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition bodyDef = root.addOrReplaceChild("body",
                CubeListBuilder.create()
                .texOffs(0, 0).addBox(-5.0F, -7.0F, -4.0F, 10.0F, 7.0F, 8.0F)
                .texOffs(0, 15).addBox(-4.0F, -8.0F, -3.0F, 8.0F, 1.0F, 6.0F),
                PartPose.offset(0.0F, 23.0F, 0.0F));
        PartDefinition sproutDef = bodyDef.addOrReplaceChild("sprout",
                CubeListBuilder.create()
                .texOffs(36, 0).addBox(-0.5F, -2.0F, -0.5F, 1.0F, 2.0F, 1.0F),
                PartPose.offset(0.0F, -8.0F, 0.0F));
        PartDefinition leafDef = bodyDef.addOrReplaceChild("leaf",
                CubeListBuilder.create()
                .texOffs(40, 0).addBox(0.0F, -0.5F, -1.0F, 3.0F, 1.0F, 2.0F),
                PartPose.offsetAndRotation(0.0F, -9.5F, 0.0F, 0.0F, 0.0F, -0.4F));
        PartDefinition armLeftDef = bodyDef.addOrReplaceChild("armLeft",
                CubeListBuilder.create()
                .texOffs(36, 4).addBox(0.0F, -1.0F, -1.0F, 2.0F, 2.0F, 2.0F),
                PartPose.offset(5.0F, -3.5F, 0.0F));
        PartDefinition armRightDef = bodyDef.addOrReplaceChild("armRight",
                CubeListBuilder.create()
                .texOffs(44, 4).addBox(-2.0F, -1.0F, -1.0F, 2.0F, 2.0F, 2.0F),
                PartPose.offset(-5.0F, -3.5F, 0.0F));
        PartDefinition footLeftDef = bodyDef.addOrReplaceChild("footLeft",
                CubeListBuilder.create()
                .texOffs(0, 22).addBox(-1.5F, 0.0F, -2.0F, 3.0F, 1.0F, 4.0F),
                PartPose.offset(2.5F, 0.0F, 0.0F));
        PartDefinition footRightDef = bodyDef.addOrReplaceChild("footRight",
                CubeListBuilder.create()
                .texOffs(14, 22).addBox(-1.5F, 0.0F, -2.0F, 3.0F, 1.0F, 4.0F),
                PartPose.offset(-2.5F, 0.0F, 0.0F));
        return LayerDefinition.create(mesh, 64, 32);
    }

    @Override
    public void setupAnim(MochiEntity entity, float limbSwing, float limbSwingAmount,
                          float ageInTicks, float netHeadYaw, float headPitch) {
        float rad = (float) Math.PI / 180.0F;
        float bounce = Math.abs(Mth.sin(limbSwing * 0.8F)) * limbSwingAmount;
        this.body.y = 23.0F - bounce * 3.0F;
        this.body.xRot = bounce * 0.12F;
        this.body.yRot = netHeadYaw * rad * 0.4F;
        this.body.zRot = Mth.sin(ageInTicks * 0.08F) * 0.03F;
        float wave = Mth.sin(ageInTicks * 0.2F) * 0.15F;
        this.armLeft.zRot = 0.3F + wave + bounce * 0.6F;
        this.armRight.zRot = -0.3F - wave - bounce * 0.6F;
        this.leaf.zRot = -0.4F + Mth.sin(ageInTicks * 0.15F) * 0.12F;
        this.sprout.zRot = Mth.sin(ageInTicks * 0.1F) * 0.05F;
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay,
                               float red, float green, float blue, float alpha) {
        this.root.render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}
