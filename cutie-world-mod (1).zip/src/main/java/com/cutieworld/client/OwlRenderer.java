package com.cutieworld.client;

import com.cutieworld.CutieWorldMod;
import com.cutieworld.entity.OwlEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;

public class OwlRenderer extends MobRenderer<OwlEntity, OwlModel> {
    private static final ResourceLocation[] TEXTURES = {texture("brown"), texture("snowy"), texture("gray")};

    public OwlRenderer(EntityRendererProvider.Context context) {
        super(context, new OwlModel(context.bakeLayer(OwlModel.LAYER_LOCATION)), 0.35F);
    }

    private static ResourceLocation texture(String color) {
        return new ResourceLocation(CutieWorldMod.MODID, "textures/entity/owl_" + color + ".png");
    }

    @Override
    public ResourceLocation getTextureLocation(OwlEntity entity) {
        return TEXTURES[entity.getVariant() % TEXTURES.length];
    }

    @Override
    protected void scale(OwlEntity entity, PoseStack poseStack, float partialTick) {
        poseStack.scale(0.9F, 0.9F, 0.9F);
    }
}
