package com.cutieworld.client;

import com.cutieworld.CutieWorldMod;
import com.cutieworld.entity.MochiEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;

public class MochiRenderer extends MobRenderer<MochiEntity, MochiModel> {
    private static final ResourceLocation[] TEXTURES = {texture("white"), texture("pink"), texture("matcha")};

    public MochiRenderer(EntityRendererProvider.Context context) {
        super(context, new MochiModel(context.bakeLayer(MochiModel.LAYER_LOCATION)), 0.35F);
    }

    private static ResourceLocation texture(String color) {
        return new ResourceLocation(CutieWorldMod.MODID, "textures/entity/mochi_" + color + ".png");
    }

    @Override
    public ResourceLocation getTextureLocation(MochiEntity entity) {
        return TEXTURES[entity.getVariant() % TEXTURES.length];
    }

    @Override
    protected void scale(MochiEntity entity, PoseStack poseStack, float partialTick) {
        poseStack.scale(1.0F, 1.0F, 1.0F);
    }
}
