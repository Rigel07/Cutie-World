package com.cutieworld.client;

import com.cutieworld.CutieWorldMod;
import com.cutieworld.entity.FairyEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;

public class FairyRenderer extends MobRenderer<FairyEntity, FairyModel> {
    private static final ResourceLocation[] TEXTURES = {texture("pink"), texture("aqua"), texture("lilac")};

    public FairyRenderer(EntityRendererProvider.Context context) {
        super(context, new FairyModel(context.bakeLayer(FairyModel.LAYER_LOCATION)), 0.15F);
    }

    private static ResourceLocation texture(String color) {
        return new ResourceLocation(CutieWorldMod.MODID, "textures/entity/fairy_" + color + ".png");
    }

    @Override
    public ResourceLocation getTextureLocation(FairyEntity entity) {
        return TEXTURES[entity.getVariant() % TEXTURES.length];
    }

    @Override
    protected void scale(FairyEntity entity, PoseStack poseStack, float partialTick) {
        poseStack.scale(1.0F, 1.0F, 1.0F);
    }

    @Override
    protected int getBlockLightLevel(FairyEntity entity, BlockPos pos) {
        return Math.max(super.getBlockLightLevel(entity, pos), 12);
    }
}
