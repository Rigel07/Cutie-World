package com.cutieworld.client;

import com.cutieworld.CutieWorldMod;
import com.cutieworld.entity.GardenBunnyEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;

public class GardenBunnyRenderer extends MobRenderer<GardenBunnyEntity, GardenBunnyModel> {
    private static final ResourceLocation[] TEXTURES = {texture("cream"), texture("brown"), texture("gray"), texture("caramel")};

    public GardenBunnyRenderer(EntityRendererProvider.Context context) {
        super(context, new GardenBunnyModel(context.bakeLayer(GardenBunnyModel.LAYER_LOCATION)), 0.3F);
    }

    private static ResourceLocation texture(String color) {
        return new ResourceLocation(CutieWorldMod.MODID, "textures/entity/garden_bunny_" + color + ".png");
    }

    @Override
    public ResourceLocation getTextureLocation(GardenBunnyEntity entity) {
        return TEXTURES[entity.getVariant() % TEXTURES.length];
    }

    @Override
    protected void scale(GardenBunnyEntity entity, PoseStack poseStack, float partialTick) {
        poseStack.scale(0.85F, 0.85F, 0.85F);
    }
}
