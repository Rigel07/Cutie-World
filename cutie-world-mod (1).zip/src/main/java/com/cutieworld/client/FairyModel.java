package com.cutieworld.client;

import com.cutieworld.CutieWorldMod;
import com.cutieworld.entity.FairyEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/** Modelo generado a partir de la especificacion de partes (ver models.py). */
public class FairyModel extends EntityModel<FairyEntity> {
    public static final ModelLayerLocation LAYER_LOCATION =
            new ModelLayerLocation(new ResourceLocation(CutieWorldMod.MODID, "fairy"), "main");

    private final ModelPart root;
    private final ModelPart body;
    private final ModelPart skirt;
    private final ModelPart head;
    private final ModelPart pigtailLeft;
    private final ModelPart pigtailRight;
    private final ModelPart armLeft;
    private final ModelPart armRight;
    private final ModelPart legLeft;
    private final ModelPart legRight;
    private final ModelPart wingLeft;
    private final ModelPart wingRight;

    public FairyModel(ModelPart root) {
        this.root = root;
        this.body = root.getChild("body");
        this.skirt = this.body.getChild("skirt");
        this.head = this.body.getChild("head");
        this.pigtailLeft = this.head.getChild("pigtailLeft");
        this.pigtailRight = this.head.getChild("pigtailRight");
        this.armLeft = this.body.getChild("armLeft");
        this.armRight = this.body.getChild("armRight");
        this.legLeft = this.body.getChild("legLeft");
        this.legRight = this.body.getChild("legRight");
        this.wingLeft = this.body.getChild("wingLeft");
        this.wingRight = this.body.getChild("wingRight");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition bodyDef = root.addOrReplaceChild("body",
                CubeListBuilder.create()
                .texOffs(0, 0).addBox(-2.0F, -2.5F, -1.5F, 4.0F, 5.0F, 3.0F),
                PartPose.offset(0.0F, 16.0F, 0.0F));
        PartDefinition skirtDef = bodyDef.addOrReplaceChild("skirt",
                CubeListBuilder.create()
                .texOffs(14, 0).addBox(-3.0F, 0.0F, -2.0F, 6.0F, 2.0F, 4.0F),
                PartPose.offset(0.0F, 2.5F, 0.0F));
        PartDefinition headDef = bodyDef.addOrReplaceChild("head",
                CubeListBuilder.create()
                .texOffs(0, 8).addBox(-3.0F, -6.0F, -3.0F, 6.0F, 6.0F, 6.0F),
                PartPose.offset(0.0F, -2.5F, 0.0F));
        PartDefinition pigtailLeftDef = headDef.addOrReplaceChild("pigtailLeft",
                CubeListBuilder.create()
                .texOffs(24, 8).addBox(0.0F, 0.0F, -1.0F, 2.0F, 4.0F, 2.0F),
                PartPose.offsetAndRotation(3.0F, -4.0F, 0.0F, 0.0F, 0.0F, -0.3F));
        PartDefinition pigtailRightDef = headDef.addOrReplaceChild("pigtailRight",
                CubeListBuilder.create()
                .texOffs(32, 8).addBox(-2.0F, 0.0F, -1.0F, 2.0F, 4.0F, 2.0F),
                PartPose.offsetAndRotation(-3.0F, -4.0F, 0.0F, 0.0F, 0.0F, 0.3F));
        PartDefinition armLeftDef = bodyDef.addOrReplaceChild("armLeft",
                CubeListBuilder.create()
                .texOffs(34, 0).addBox(0.0F, 0.0F, -1.0F, 1.0F, 4.0F, 2.0F),
                PartPose.offset(2.5F, -2.0F, 0.0F));
        PartDefinition armRightDef = bodyDef.addOrReplaceChild("armRight",
                CubeListBuilder.create()
                .texOffs(40, 0).addBox(-1.0F, 0.0F, -1.0F, 1.0F, 4.0F, 2.0F),
                PartPose.offset(-2.5F, -2.0F, 0.0F));
        PartDefinition legLeftDef = bodyDef.addOrReplaceChild("legLeft",
                CubeListBuilder.create()
                .texOffs(46, 0).addBox(-0.5F, 0.0F, -1.0F, 1.0F, 4.0F, 2.0F),
                PartPose.offset(1.0F, 2.5F, 0.0F));
        PartDefinition legRightDef = bodyDef.addOrReplaceChild("legRight",
                CubeListBuilder.create()
                .texOffs(52, 0).addBox(-0.5F, 0.0F, -1.0F, 1.0F, 4.0F, 2.0F),
                PartPose.offset(-1.0F, 2.5F, 0.0F));
        PartDefinition wingLeftDef = bodyDef.addOrReplaceChild("wingLeft",
                CubeListBuilder.create()
                .texOffs(0, 20).addBox(0.0F, -5.0F, 0.0F, 6.0F, 9.0F, 1.0F),
                PartPose.offset(1.0F, -1.5F, 1.5F));
        PartDefinition wingRightDef = bodyDef.addOrReplaceChild("wingRight",
                CubeListBuilder.create()
                .texOffs(14, 20).addBox(-6.0F, -5.0F, 0.0F, 6.0F, 9.0F, 1.0F),
                PartPose.offset(-1.0F, -1.5F, 1.5F));
        return LayerDefinition.create(mesh, 64, 32);
    }

    @Override
    public void setupAnim(FairyEntity entity, float limbSwing, float limbSwingAmount,
                          float ageInTicks, float netHeadYaw, float headPitch) {
        float rad = (float) Math.PI / 180.0F;
        this.head.yRot = netHeadYaw * rad;
        this.head.xRot = headPitch * rad;
        this.body.y = 16.0F + Mth.sin(ageInTicks * 0.1F) * 1.0F;
        this.body.xRot = 0.15F;
        float flap = Mth.cos(ageInTicks * 1.4F) * 0.6F;
        this.wingLeft.yRot = -0.5F - flap;
        this.wingRight.yRot = 0.5F + flap;
        this.wingLeft.zRot = 0.15F;
        this.wingRight.zRot = -0.15F;
        this.armLeft.zRot = -0.3F - Mth.sin(ageInTicks * 0.15F) * 0.1F;
        this.armRight.zRot = 0.3F + Mth.sin(ageInTicks * 0.15F) * 0.1F;
        this.legLeft.xRot = Mth.sin(ageInTicks * 0.12F) * 0.2F;
        this.legRight.xRot = -Mth.sin(ageInTicks * 0.12F) * 0.2F;
        this.pigtailLeft.zRot = -0.3F - Mth.sin(ageInTicks * 0.2F) * 0.1F;
        this.pigtailRight.zRot = 0.3F + Mth.sin(ageInTicks * 0.2F) * 0.1F;
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay,
                               float red, float green, float blue, float alpha) {
        this.root.render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}
