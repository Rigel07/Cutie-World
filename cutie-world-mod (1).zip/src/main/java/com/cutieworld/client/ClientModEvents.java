package com.cutieworld.client;

import com.cutieworld.CutieWorldMod;
import com.cutieworld.registry.ModEntities;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = CutieWorldMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientModEvents {
    private ClientModEvents() {}

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.MOCHI.get(), MochiRenderer::new);
        event.registerEntityRenderer(ModEntities.FAIRY.get(), FairyRenderer::new);
        event.registerEntityRenderer(ModEntities.GARDEN_BUNNY.get(), GardenBunnyRenderer::new);
        event.registerEntityRenderer(ModEntities.OWL.get(), OwlRenderer::new);
    }

    @SubscribeEvent
    public static void registerLayers(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(MochiModel.LAYER_LOCATION, MochiModel::createBodyLayer);
        event.registerLayerDefinition(FairyModel.LAYER_LOCATION, FairyModel::createBodyLayer);
        event.registerLayerDefinition(GardenBunnyModel.LAYER_LOCATION, GardenBunnyModel::createBodyLayer);
        event.registerLayerDefinition(OwlModel.LAYER_LOCATION, OwlModel::createBodyLayer);
    }
}
