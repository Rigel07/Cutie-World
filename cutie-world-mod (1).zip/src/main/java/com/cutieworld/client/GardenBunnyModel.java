package com.cutieworld.client;

import com.cutieworld.CutieWorldMod;
import com.cutieworld.entity.GardenBunnyEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/** Modelo generado a partir de la especificacion de partes (ver models.py). */
public class GardenBunnyModel extends EntityModel<GardenBunnyEntity> {
    public static final ModelLayerLocation LAYER_LOCATION =
            new ModelLayerLocation(new ResourceLocation(CutieWorldMod.MODID, "garden_bunny"), "main");

    private final ModelPart root;
    private final ModelPart body;
    private final ModelPart head;
    private final ModelPart nose;
    private final ModelPart earLeft;
    private final ModelPart earRight;
    private final ModelPart hatBrim;
    private final ModelPart hatCrown;
    private final ModelPart tail;
    private final ModelPart legFrontLeft;
    private final ModelPart legFrontRight;
    private final ModelPart legBackLeft;
    private final ModelPart legBackRight;

    public GardenBunnyModel(ModelPart root) {
        this.root = root;
        this.body = root.getChild("body");
        this.head = this.body.getChild("head");
        this.nose = this.head.getChild("nose");
        this.earLeft = this.head.getChild("earLeft");
        this.earRight = this.head.getChild("earRight");
        this.hatBrim = this.head.getChild("hatBrim");
        this.hatCrown = this.head.getChild("hatCrown");
        this.tail = this.body.getChild("tail");
        this.legFrontLeft = this.body.getChild("legFrontLeft");
        this.legFrontRight = this.body.getChild("legFrontRight");
        this.legBackLeft = this.body.getChild("legBackLeft");
        this.legBackRight = this.body.getChild("legBackRight");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition bodyDef = root.addOrReplaceChild("body",
                CubeListBuilder.create()
                .texOffs(0, 0).addBox(-2.5F, -2.5F, -4.0F, 5.0F, 5.0F, 8.0F),
                PartPose.offset(0.0F, 18.5F, 0.0F));
        PartDefinition headDef = bodyDef.addOrReplaceChild("head",
                CubeListBuilder.create()
                .texOffs(26, 0).addBox(-2.5F, -2.5F, -4.0F, 5.0F, 5.0F, 4.0F),
                PartPose.offset(0.0F, -1.5F, -4.0F));
        PartDefinition noseDef = headDef.addOrReplaceChild("nose",
                CubeListBuilder.create()
                .texOffs(44, 0).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 2.0F, 1.0F),
                PartPose.offset(0.0F, 0.0F, -4.0F));
        PartDefinition earLeftDef = headDef.addOrReplaceChild("earLeft",
                CubeListBuilder.create()
                .texOffs(50, 0).addBox(-1.0F, -6.0F, -0.5F, 2.0F, 6.0F, 1.0F),
                PartPose.offset(1.5F, -2.5F, -1.5F));
        PartDefinition earRightDef = headDef.addOrReplaceChild("earRight",
                CubeListBuilder.create()
                .texOffs(56, 0).addBox(-1.0F, -6.0F, -0.5F, 2.0F, 6.0F, 1.0F),
                PartPose.offset(-1.5F, -2.5F, -1.5F));
        PartDefinition hatBrimDef = headDef.addOrReplaceChild("hatBrim",
                CubeListBuilder.create()
                .texOffs(0, 13).addBox(-4.5F, -1.0F, -6.0F, 9.0F, 1.0F, 8.0F),
                PartPose.offset(0.0F, -2.5F, 0.0F));
        PartDefinition hatCrownDef = headDef.addOrReplaceChild("hatCrown",
                CubeListBuilder.create()
                .texOffs(34, 13).addBox(-1.5F, -3.0F, -3.5F, 3.0F, 3.0F, 3.0F),
                PartPose.offset(0.0F, -3.5F, 0.0F));
        PartDefinition tailDef = bodyDef.addOrReplaceChild("tail",
                CubeListBuilder.create()
                .texOffs(0, 22).addBox(-1.5F, -1.5F, 0.0F, 3.0F, 3.0F, 2.0F),
                PartPose.offset(0.0F, 0.0F, 4.0F));
        PartDefinition legFrontLeftDef = bodyDef.addOrReplaceChild("legFrontLeft",
                CubeListBuilder.create()
                .texOffs(10, 22).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 3.0F, 1.0F),
                PartPose.offset(1.5F, 2.5F, -2.5F));
        PartDefinition legFrontRightDef = bodyDef.addOrReplaceChild("legFrontRight",
                CubeListBuilder.create()
                .texOffs(14, 22).addBox(-0.5F, 0.0F, -0.5F, 1.0F, 3.0F, 1.0F),
                PartPose.offset(-1.5F, 2.5F, -2.5F));
        PartDefinition legBackLeftDef = bodyDef.addOrReplaceChild("legBackLeft",
                CubeListBuilder.create()
                .texOffs(18, 22).addBox(-1.0F, 0.0F, -1.5F, 2.0F, 3.0F, 3.0F),
                PartPose.offset(2.0F, 2.0F, 3.0F));
        PartDefinition legBackRightDef = bodyDef.addOrReplaceChild("legBackRight",
                CubeListBuilder.create()
                .texOffs(28, 22).addBox(-1.0F, 0.0F, -1.5F, 2.0F, 3.0F, 3.0F),
                PartPose.offset(-2.0F, 2.0F, 3.0F));
        return LayerDefinition.create(mesh, 64, 32);
    }

    @Override
    public void setupAnim(GardenBunnyEntity entity, float limbSwing, float limbSwingAmount,
                          float ageInTicks, float netHeadYaw, float headPitch) {
        float rad = (float) Math.PI / 180.0F;
        this.head.yRot = netHeadYaw * rad;
        this.head.xRot = headPitch * rad;
        float hop = Math.abs(Mth.sin(limbSwing * 0.9F)) * limbSwingAmount;
        this.body.y = 18.5F - hop * 3.0F;
        this.body.xRot = -hop * 0.35F;
        this.legFrontLeft.xRot = -hop * 0.9F;
        this.legFrontRight.xRot = -hop * 0.9F;
        this.legBackLeft.xRot = hop * 1.0F;
        this.legBackRight.xRot = hop * 1.0F;
        float twitch = Mth.sin(ageInTicks * 0.07F) * 0.05F;
        this.earLeft.zRot = 0.12F + hop * 0.4F + twitch;
        this.earRight.zRot = -0.7F - hop * 0.2F - twitch;
        this.tail.yRot = Mth.sin(ageInTicks * 0.2F) * 0.3F;
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay,
                               float red, float green, float blue, float alpha) {
        this.root.render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}
