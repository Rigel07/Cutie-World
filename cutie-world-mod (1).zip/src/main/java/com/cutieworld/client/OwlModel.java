package com.cutieworld.client;

import com.cutieworld.CutieWorldMod;
import com.cutieworld.entity.OwlEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/** Modelo generado a partir de la especificacion de partes (ver models.py). */
public class OwlModel extends EntityModel<OwlEntity> {
    public static final ModelLayerLocation LAYER_LOCATION =
            new ModelLayerLocation(new ResourceLocation(CutieWorldMod.MODID, "owl"), "main");

    private final ModelPart root;
    private final ModelPart body;
    private final ModelPart head;
    private final ModelPart beak;
    private final ModelPart tuftLeft;
    private final ModelPart tuftRight;
    private final ModelPart wingLeft;
    private final ModelPart wingRight;
    private final ModelPart tail;
    private final ModelPart footLeft;
    private final ModelPart footRight;

    public OwlModel(ModelPart root) {
        this.root = root;
        this.body = root.getChild("body");
        this.head = this.body.getChild("head");
        this.beak = this.head.getChild("beak");
        this.tuftLeft = this.head.getChild("tuftLeft");
        this.tuftRight = this.head.getChild("tuftRight");
        this.wingLeft = this.body.getChild("wingLeft");
        this.wingRight = this.body.getChild("wingRight");
        this.tail = this.body.getChild("tail");
        this.footLeft = this.body.getChild("footLeft");
        this.footRight = this.body.getChild("footRight");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        PartDefinition bodyDef = root.addOrReplaceChild("body",
                CubeListBuilder.create()
                .texOffs(0, 0).addBox(-3.5F, -9.0F, -3.0F, 7.0F, 9.0F, 6.0F),
                PartPose.offset(0.0F, 23.0F, 0.0F));
        PartDefinition headDef = bodyDef.addOrReplaceChild("head",
                CubeListBuilder.create()
                .texOffs(0, 15).addBox(-4.0F, -7.0F, -3.5F, 8.0F, 7.0F, 7.0F),
                PartPose.offset(0.0F, -8.0F, 0.0F));
        PartDefinition beakDef = headDef.addOrReplaceChild("beak",
                CubeListBuilder.create()
                .texOffs(26, 0).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 2.0F, 1.0F),
                PartPose.offset(0.0F, -3.0F, -3.5F));
        PartDefinition tuftLeftDef = headDef.addOrReplaceChild("tuftLeft",
                CubeListBuilder.create()
                .texOffs(32, 0).addBox(-1.0F, -2.0F, -1.0F, 2.0F, 2.0F, 2.0F),
                PartPose.offsetAndRotation(2.5F, -7.0F, -1.5F, 0.0F, 0.0F, 0.25F));
        PartDefinition tuftRightDef = headDef.addOrReplaceChild("tuftRight",
                CubeListBuilder.create()
                .texOffs(40, 0).addBox(-1.0F, -2.0F, -1.0F, 2.0F, 2.0F, 2.0F),
                PartPose.offsetAndRotation(-2.5F, -7.0F, -1.5F, 0.0F, 0.0F, -0.25F));
        PartDefinition wingLeftDef = bodyDef.addOrReplaceChild("wingLeft",
                CubeListBuilder.create()
                .texOffs(30, 15).addBox(0.0F, 0.0F, -2.0F, 1.0F, 7.0F, 4.0F),
                PartPose.offset(3.5F, -8.0F, 0.0F));
        PartDefinition wingRightDef = bodyDef.addOrReplaceChild("wingRight",
                CubeListBuilder.create()
                .texOffs(40, 15).addBox(-1.0F, 0.0F, -2.0F, 1.0F, 7.0F, 4.0F),
                PartPose.offset(-3.5F, -8.0F, 0.0F));
        PartDefinition tailDef = bodyDef.addOrReplaceChild("tail",
                CubeListBuilder.create()
                .texOffs(48, 0).addBox(-2.0F, -3.0F, 0.0F, 4.0F, 3.0F, 1.0F),
                PartPose.offset(0.0F, -1.0F, 3.0F));
        PartDefinition footLeftDef = bodyDef.addOrReplaceChild("footLeft",
                CubeListBuilder.create()
                .texOffs(50, 15).addBox(-1.0F, 0.0F, -1.5F, 2.0F, 1.0F, 3.0F),
                PartPose.offset(1.5F, 0.0F, 0.0F));
        PartDefinition footRightDef = bodyDef.addOrReplaceChild("footRight",
                CubeListBuilder.create()
                .texOffs(50, 19).addBox(-1.0F, 0.0F, -1.5F, 2.0F, 1.0F, 3.0F),
                PartPose.offset(-1.5F, 0.0F, 0.0F));
        return LayerDefinition.create(mesh, 64, 32);
    }

    @Override
    public void setupAnim(OwlEntity entity, float limbSwing, float limbSwingAmount,
                          float ageInTicks, float netHeadYaw, float headPitch) {
        float rad = (float) Math.PI / 180.0F;
        this.head.yRot = netHeadYaw * rad;
        this.head.xRot = headPitch * rad;
        this.body.y = 23.0F + Mth.sin(ageInTicks * 0.06F) * 0.3F;
        float swing = Mth.cos(limbSwing * 0.6662F) * limbSwingAmount;
        this.body.zRot = swing * 0.1F;
        this.footLeft.xRot = swing * 1.2F;
        this.footRight.xRot = -swing * 1.2F;
        this.wingLeft.zRot = 0.12F + Mth.sin(ageInTicks * 0.1F) * 0.05F;
        this.wingRight.zRot = -this.wingLeft.zRot;
        this.tail.xRot = 0.25F + Mth.sin(ageInTicks * 0.08F) * 0.05F;
        this.tuftLeft.zRot = 0.25F + Mth.sin(ageInTicks * 0.13F) * 0.05F;
        this.tuftRight.zRot = -this.tuftLeft.zRot;
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay,
                               float red, float green, float blue, float alpha) {
        this.root.render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}
